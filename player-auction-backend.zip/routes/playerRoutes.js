const router = require("express").Router();
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const Player = require("../models/Player");

router.get("/profile", auth, role("player"), async (req, res) => {
  const player = await Player.findOne({ userId: req.user.id });
  res.json(player);
});

router.put("/profile", auth, role("player"), async (req, res) => {
  const updated = await Player.findOneAndUpdate(
    { userId: req.user.id },
    req.body,
    { new: true }
  );
  res.json(updated);
});

module.exports = router;