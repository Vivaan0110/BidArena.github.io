module.exports = (io) => {
  let currentBid = 0;
  let highestTeam = null;

  io.on("connection", (socket) => {
    socket.on("joinAuction", () => socket.join("LIVE_AUCTION"));

    socket.on("placeBid", ({ bidAmount, teamId }) => {
      if (bidAmount > currentBid) {
        currentBid = bidAmount;
        highestTeam = teamId;
        io.to("LIVE_AUCTION").emit("newBid", { bidAmount, teamId });
      }
    });
  });
};