
import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import io from "socket.io-client";

const socket = io("http://localhost:5000");

const Home = () => (
  <div>
    <h1>Player Auction</h1>
    <Link to="/register">Register</Link> | <Link to="/auction">Auction</Link>
  </div>
);

const Register = () => (
  <div>
    <h2>Register</h2>
    <input placeholder="Name"/><br/>
    <input placeholder="Email"/><br/>
    <select><option>Player</option><option>Owner</option></select><br/>
    <button>Register</button>
  </div>
);

const Auction = () => {
  const bid = () => socket.emit("placeBid",{amount:10000});
  socket.on("newBid",d=>console.log(d));
  return (
    <div>
      <h2>Live Auction</h2>
      <button onClick={bid}>Bid 10000</button>
    </div>
  );
};

export default function App(){
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/auction" element={<Auction/>}/>
      </Routes>
    </BrowserRouter>
  );
}
